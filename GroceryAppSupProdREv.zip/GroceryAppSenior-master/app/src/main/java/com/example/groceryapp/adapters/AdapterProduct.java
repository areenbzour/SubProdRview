package com.example.groceryapp.adapters;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

//import com.example.groceryapp.FilterProduct;
import com.example.groceryapp.activities.MainUserActivity;
import com.example.groceryapp.activities.ProductReview;
import com.example.groceryapp.activities.ShopReviewActivity;
import com.example.groceryapp.activities.prdwriteReview;
import com.example.groceryapp.activities.writwReviewActivity;
import com.example.groceryapp.models.ModelProduct;
import com.example.groceryapp.R;
import com.example.groceryapp.FilterProduct;
import com.example.groceryapp.models.ModelSupermarket;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.core.view.Event;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;

public class AdapterProduct extends RecyclerView.Adapter<AdapterProduct.HolderProduct> implements Filterable {
    public int shLid=0;
    private Context context;
    public ArrayList<ModelProduct> productList;
    public ArrayList<ModelProduct> filterList;
    public ArrayList<ModelProduct> cartOfproducts=new ArrayList<>();
    private FilterProduct filter;
    private Boolean showAddToCart;



    public ArrayList<ModelProduct> getCartOfproducts() {
        return cartOfproducts;
    }



    public AdapterProduct(Context context, ArrayList<ModelProduct> productList, Boolean showAddToCart) {
        this.context = context;
        this.productList = productList;
        this.filterList = productList;
        this.showAddToCart = showAddToCart;
    }

    @NonNull
    @Override
    public HolderProduct onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //inflate layout
        View view = LayoutInflater.from(context).inflate(R.layout.product_item,parent,false);
        return new HolderProduct(view);

    }

    @Override
    public void onBindViewHolder(@NonNull HolderProduct holder, int position) {
        //get data
        ModelProduct modelProduct = productList.get(position);
        String id = modelProduct.getProductId();
        String category = modelProduct.getProductCategory();
        String icon = modelProduct.getProductIcon();
        String name = modelProduct.getProductName();
        double averagePrice=modelProduct.getAveragePrice();


        //LoadpReviews(modelProduct,holder);



        holder.prateIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1=new Intent(view.getContext(), prdwriteReview.class);
                intent1.putExtra("pruductR", productList.get(holder.getAdapterPosition()));
                view.getContext().startActivity(intent1);
            }
        });

        holder.pshreviewIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(view.getContext(), ProductReview.class);
                intent.putExtra("pruductR",modelProduct);
                view.getContext().startActivity(intent);
            }
        });

        holder.addToShoppingListTv.setVisibility( showAddToCart ? View.VISIBLE : View.GONE);

       ///set data
        holder.productNameTv.setText(name);

        holder.averagePriceTv.setText(String.valueOf(averagePrice+"$"));


        try{
            Picasso.get().load(icon).placeholder(R.drawable.ic_shopping_cart).into(holder.productIconIv);
        }
        catch (Exception e){
            holder.productIconIv.setImageResource(R.drawable.ic_shopping_cart);
        }

        holder.addToShoppingListTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //add to shopping list
                showQuantityDialog(modelProduct);
            }
        });

    }

    private int quantity = 0;
    private void showQuantityDialog(ModelProduct modelProduct) {
        //inflate layout for dialog
        View view = LayoutInflater.from(context).inflate(R.layout.dialog_quantity,null);
        //init layout views
        ImageView productIv = view.findViewById(R.id.productIv);
        TextView pNameTv = view.findViewById(R.id.pNameTv);
        TextView pAvgpriceTv=view.findViewById(R.id.pAvgpriceTv);
        ImageButton decrementBtn = view.findViewById(R.id.decrementBtn);
        TextView quantityTv = view.findViewById(R.id.quantityTv);
        ImageButton incrementBtn = view.findViewById(R.id.incrementBtn);
        Button continueBtn = view.findViewById(R.id.continueBtn);

        
        //get data from model
        String productId = modelProduct.getProductId();
        String icon = modelProduct.getProductIcon();
        String name = modelProduct.getProductName();
        double avgp=modelProduct.getAveragePrice();

        quantity = 1;
        
        //dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setView(view);

        try{
            Picasso.get().load(icon).placeholder(R.drawable.ic_cart).into(productIv);
        }
        catch (Exception e) {
            productIv.setImageResource(R.drawable.ic_cart);
        }
        
        pNameTv.setText(""+name);
        quantityTv.setText(""+quantity);
        pAvgpriceTv.setText(""+avgp);

        
        AlertDialog dialog = builder.create();
        dialog.show();

        
        //increase quantity of the product
        incrementBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                quantity++;
                quantityTv.setText(""+quantity);
            }
        });

        //decrease quantity of the product
        decrementBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(quantity>1){
                    quantity--;
                    quantityTv.setText(""+quantity);
                }
            }
        });

        //Add to cart button in the product's dialog
         continueBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = pNameTv.getText().toString().trim();
                String quantity = quantityTv.getText().toString().trim();
                String averagePrice1=pAvgpriceTv.getText().toString().trim();
                double avgPrice=Double.parseDouble(averagePrice1);
                double quant=Double.parseDouble(quantity);
                avgPrice=avgPrice*quant;

                
                //add to db
                //addToShoppingList(productId,name,quantity,view);
                addTocart(productId,name,quantity,icon,avgPrice,view);
                dialog.dismiss();;
            }
        });
    }


    private void addTocart(String id, String name, String quantity,String icon,double averagePrice,View v) {
        ModelProduct  prod =new ModelProduct(id,name,quantity,icon,averagePrice);
        cartOfproducts.add(prod);

        final DatabaseReference cartOfshoppinglist= FirebaseDatabase.getInstance().getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("Cartt");

        cartOfshoppinglist
                .child(id)
                .setValue(
                        prod
                ).addOnCompleteListener(task -> {
            if (task.isSuccessful()){
                Toast.makeText(v.getContext(), "Adeed to cart", Toast.LENGTH_SHORT).show();
            }
        });

        Intent intent = new Intent();
        intent.putExtra("CartOfProducts", cartOfproducts);

    }


    private float pratinngSum=0;
    private void LoadpReviews(ModelProduct modelProduct, AdapterProduct.HolderProduct holder) {
        String prId=modelProduct.getProductId();
        FirebaseDatabase.getInstance().getReference().child("Products")
                .child(prId).child("Ratings").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                pratinngSum=0;
                for (DataSnapshot ds : snapshot.getChildren()) {
                    float prating=Float.parseFloat(""+ds.child("ratings").getValue());
                    pratinngSum=pratinngSum+prating;
                }

                long numberOfpReviews= snapshot.getChildrenCount();
                float avgpRating=pratinngSum/numberOfpReviews;
                holder.ratingBar5.setRating(avgpRating);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }


    @Override
    public int getItemCount() {
        return productList.size();
    }

    @Override
    public Filter getFilter() {
        if(filter==null) {
            filter = new FilterProduct(this, filterList);
        }
        return filter;
    }

    class HolderProduct extends RecyclerView.ViewHolder{

        private ImageView productIconIv;
        private ImageView prateIv,pshreviewIv;
        private TextView productNameTv, addToShoppingListTv,averagePriceTv;
        public RatingBar ratingBar5;

        public HolderProduct(@NonNull View itemView) {
            super(itemView);

            productIconIv = itemView.findViewById(R.id.productIconIv);
            productNameTv = itemView.findViewById(R.id.productNameTv);
            addToShoppingListTv = itemView.findViewById(R.id.addToShoppingListTv);
            averagePriceTv=itemView.findViewById(R.id.averagePriceTv);
            prateIv=itemView.findViewById(R.id.prateIv);
            pshreviewIv=itemView.findViewById(R.id. pshreviewIv);
            //ratingBar5=itemView.findViewById(R.id.ratingBar5);
        }

        public TextView getAddToShoppingListTv() {
            return addToShoppingListTv;
        }
    }
}
