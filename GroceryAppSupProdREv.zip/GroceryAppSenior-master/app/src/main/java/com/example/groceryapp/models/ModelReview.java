package com.example.groceryapp.models;

public class ModelReview {

    String uid,ratings,review,timestamp;

    public ModelReview() {

    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public void setRatings(String ratings) {
        this.ratings = ratings;
    }

    public void setReview(String review) {
        this.review = review;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getUid() {
        return uid;
    }

    public String getRatings() {
        return ratings;
    }

    public String getReview() {
        return review;
    }

    public String getTimestamp() {
        return timestamp;
    }
}
