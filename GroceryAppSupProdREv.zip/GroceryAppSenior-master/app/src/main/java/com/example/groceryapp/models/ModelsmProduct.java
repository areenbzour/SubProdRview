package com.example.groceryapp.models;

import java.io.Serializable;

public class ModelsmProduct implements Serializable {
    private Double realPrice;
    private String productId;

    public ModelsmProduct(){}
    
    public ModelsmProduct(Double realPrice, String productId) {
        this.realPrice = realPrice;
        this.productId = productId;
    }

    public Double getRealPrice() {
        return realPrice;
    }

    public void setRealPrice(Double realPrice) {
        this.realPrice = realPrice;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }
}
