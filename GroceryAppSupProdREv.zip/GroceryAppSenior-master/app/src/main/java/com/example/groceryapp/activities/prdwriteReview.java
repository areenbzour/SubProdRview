package com.example.groceryapp.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.groceryapp.R;
import com.example.groceryapp.models.ModelProduct;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;

import java.util.HashMap;

public class prdwriteReview extends AppCompatActivity {

    private String prName,prId;

    private ImageButton pbackBtn;
    private ImageView pprofileIv;
    private RatingBar pratingBar;
    private EditText previewEt;
    private FloatingActionButton psubmitButn;
    private TextView prNameTv;
    private TextView prIdTv;
    private FirebaseAuth firebaseAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prdwrite_review);

        ModelProduct pr=(ModelProduct) getIntent().getSerializableExtra("pruductR");
        prId = pr.getProductId();

        pbackBtn = findViewById(R.id.pbackBtn);
        pprofileIv = findViewById(R.id.pprofileIv);
        prNameTv = findViewById(R.id.prNameTv);
        prIdTv = findViewById(R.id.prIdTv);
        pratingBar = findViewById(R.id.pratingBar);
        psubmitButn = findViewById(R.id.psubmitButn);
        previewEt = findViewById(R.id.previewEt);

        prNameTv.setText(pr.getProductName());
        prIdTv.setText(pr.getProductId());
        Picasso.get().load(pr.getProductIcon()).into(pprofileIv);


        firebaseAuth = FirebaseAuth.getInstance();

        pbackBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        psubmitButn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                inputData(view);
            }
        });
    }


    private void inputData(View v) {
        String ratings = "" + pratingBar.getRating();
        String review = previewEt.getText().toString().trim();

        String timestamp = "" + System.currentTimeMillis();

        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("uid", "" + firebaseAuth.getUid());
        hashMap.put("ratings", "" + ratings);
        hashMap.put("review", "" + review);
        hashMap.put("timestamp", "" + timestamp);

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Products").child(prId).child("Ratings");
        ref
                .push()
                .setValue(hashMap).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Toast.makeText(v.getContext(), "Review published Successfuly" +
                        "", Toast.LENGTH_SHORT).show();
            }
        });
    }


}