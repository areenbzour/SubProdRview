package com.example.groceryapp.adapters;

import android.content.Context;
import android.content.Intent;
import android.media.session.MediaController;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.groceryapp.R;
import com.example.groceryapp.activities.ShopReviewActivity;
import com.example.groceryapp.activities.SupermarketActivity;
import com.example.groceryapp.activities.writwReviewActivity;
import com.example.groceryapp.models.*;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class AdapterSupermarket extends RecyclerView.Adapter<AdapterSupermarket.HolderSupermarket>{

    private Context context;
    public ArrayList<ModelSupermarket> supermarketList;

    public AdapterSupermarket(Context context, ArrayList<ModelSupermarket> supermarketList) {
        this.context = context;
        this.supermarketList = supermarketList;
    }

    @NonNull
    @Override
    public HolderSupermarket onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //inflate layout
        View view = LayoutInflater.from(context).inflate(R.layout.show_supermarket,parent,false);
        return new HolderSupermarket(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HolderSupermarket holder, int position) {

        //get data
        ModelSupermarket modelSupermarket = supermarketList.get(position);
        String id = modelSupermarket.getSupermarketId();
        String supermarketAddress = modelSupermarket.getAddress();
        String icon = modelSupermarket.getSupermarketImage();
        String name = modelSupermarket.getSupermarketName();

        //LoadReviews(modelSupermarket,holder);

        holder.rateIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1=new Intent(view.getContext(), writwReviewActivity.class);
                intent1.putExtra("supermarket",modelSupermarket);
                view.getContext().startActivity(intent1);
            }
        });

        holder.shreviewIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(view.getContext(), ShopReviewActivity.class);
                intent.putExtra("supermarket",modelSupermarket);
                view.getContext().startActivity(intent);
            }
        });


        ///set data
        holder.supermarketNameTv.setText(name);
        holder.supermarketAddressTv.setText(supermarketAddress);

        try{
            Picasso.get().load(icon).placeholder(R.drawable.ic_store).into(holder.supermarketIconIv);
        }
        catch (Exception e){
            holder.supermarketIconIv.setImageResource(R.drawable.ic_store);
        }

    }
    private float ratinngSum=0;
    private void LoadReviews(ModelSupermarket modelSupermarket, HolderSupermarket holder) {
        String shopId=modelSupermarket.getSupermarketId();
        FirebaseDatabase.getInstance().getReference().child("Supermarkets")
                .child(shopId).child("Ratings").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                ratinngSum=0;
                for (DataSnapshot ds : snapshot.getChildren()) {
                    float rating=Float.parseFloat(""+ds.child("ratings").getValue());
                    ratinngSum=ratinngSum+rating;
                }

                long numberOfReviews= snapshot.getChildrenCount();
                float avgRating=ratinngSum/numberOfReviews;
                holder.ratingBar4.setRating(avgRating);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    @Override
    public int getItemCount() {
        return supermarketList.size();
    }

    //view holder
    class HolderSupermarket extends RecyclerView.ViewHolder{

        public RatingBar ratingBar4;
        private ImageView supermarketIconIv,rateIv,shreviewIv;
        private TextView supermarketNameTv, supermarketAddressTv;

        public HolderSupermarket(@NonNull View itemView) {
            super(itemView);

            supermarketIconIv = itemView.findViewById(R.id.supermarketIconIv);
            supermarketNameTv = itemView.findViewById(R.id.supermarketNameTv);
            supermarketAddressTv = itemView.findViewById(R.id.supermarketAddressTv);
            rateIv=itemView.findViewById(R.id.rateIv);
            shreviewIv=itemView.findViewById(R.id.shreviewIv);
            //ratingBar4=itemView.findViewById(R.id.ratingBar4);
        }
    }
}
