package com.example.groceryapp;

public class Constants {

    //product categories
    public static final String[] productCategories = {
            "Beverages",
            "Cooking Needs",
            "Breakfast & Dairy",
            "Chocolates",
            "Canned Foods",
            "Personal Care",
            "Cleaners",
            "Baby Kids",
            "Frozen Foods"
    };

    public static final String[] productCategories1 = {
            "All",
            "Beverages",
            "Cooking Needs",
            "Breakfast & Dairy",
            "Chocolates",
            "Canned Foods",
            "Personal Care",
            "Cleaners",
            "Baby Kids",
            "Frozen Foods"
    };
}
