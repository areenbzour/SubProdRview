package com.example.groceryapp.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.example.groceryapp.R;
import com.example.groceryapp.adapters.AdapterOrderUser;
import com.example.groceryapp.adapters.AdapterReview;
import com.example.groceryapp.models.ModelOrderUser;
import com.example.groceryapp.models.ModelReview;
import com.example.groceryapp.models.ModelSupermarket;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class ShopReviewActivity extends AppCompatActivity {

    private ArrayList<ModelReview> reviewsList;
     private AdapterReview adapterReview;

    private ImageButton backBtn;
    private ImageView profileIv2;
    private TextView shopNameTv2,ratingsTv;
    private RatingBar ratingBar2;
    private RecyclerView reviewRv;


    private String shopId;
    private TextView shopIdTv;
    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop_review);

        ModelSupermarket sm = (ModelSupermarket) getIntent().getSerializableExtra("supermarket");
        shopId = sm.getSupermarketId();

        backBtn=findViewById(R.id.backBtn);
        profileIv2=findViewById(R.id.profileIv2);
        shopNameTv2=findViewById(R.id.shopNameTv2);
        ratingBar2=findViewById(R.id.ratingBar2);
        ratingsTv=findViewById(R.id.ratingsTv);
        reviewRv=findViewById(R.id.reviewRv);

        shopNameTv2.setText(sm.getSupermarketName());
        try {
            Picasso.get().load(sm.getSupermarketImage()).into(profileIv2);
        } catch (Exception e) {
            profileIv2.setImageResource(R.drawable.ic_store);
        }
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });


        LoadReviews();



    }
    private float ratinngSum=0;
    private void LoadReviews() {

        reviewsList = new ArrayList<>();
        adapterReview = new AdapterReview(ShopReviewActivity.this, reviewsList);
        reviewRv.setAdapter(adapterReview);
        FirebaseDatabase.getInstance().getReference().child("Supermarkets")
                .child(shopId).child("Ratings").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                ratinngSum=0;
                for (DataSnapshot ds : snapshot.getChildren()) {
                    float rating=Float.parseFloat(""+ds.child("ratings").getValue());
                    ratinngSum=ratinngSum+rating;
                    ModelReview modelReview = ds.getValue(ModelReview.class);
                    reviewsList.add(modelReview);

                }

                adapterReview.submitList(reviewsList);
                long numOfRev=snapshot.getChildrenCount();
                float avgRat=ratinngSum/numOfRev;

                ratingsTv.setText(String.format("%.2f",avgRat)+"["+numOfRev+"]");
                ratingBar2.setRating(avgRat);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }
}