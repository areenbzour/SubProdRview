package com.example.groceryapp.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.example.groceryapp.R;
import com.example.groceryapp.adapters.AdapterProdReview;
import com.example.groceryapp.adapters.AdapterReview;
import com.example.groceryapp.models.ModelProduct;
import com.example.groceryapp.models.ModelReview;
import com.example.groceryapp.models.ModelSupermarket;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class ProductReview extends AppCompatActivity {



    private ArrayList<ModelReview> previewsList;
    private AdapterProdReview adapterProdReview;

    private ImageButton backBtn;
    private ImageView pprofileIv2;
    private TextView prNameTv2,pratingsTv;
    private RatingBar pratingBar2;
    private RecyclerView previewRv;


    private String prId;

    private FirebaseAuth firebaseAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_review);
        //prid=

        ModelProduct pr=(ModelProduct) getIntent().getSerializableExtra("pruductR") ;
        prId = pr.getProductId();

        backBtn=findViewById(R.id.backBtn);
        pprofileIv2=findViewById(R.id.pprofileIv2);
        prNameTv2=findViewById(R.id.prNameTv2);
        pratingBar2=findViewById(R.id.pratingBar2);
        pratingsTv=findViewById(R.id.pratingsTv);
        previewRv=findViewById(R.id.previewRv);

        prNameTv2.setText(pr.getProductName());
        try {
            Picasso.get().load(pr.getProductIcon()).into(pprofileIv2);
        } catch (Exception e) {
            pprofileIv2.setImageResource(R.drawable.ic_store);
        }
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });


        LoadReviews();



    }
    private float pratinngSum=0;
    private void LoadReviews() {

        previewsList = new ArrayList<>();

        adapterProdReview= new AdapterProdReview(ProductReview.this, previewsList);
        previewRv.setAdapter(adapterProdReview);
        FirebaseDatabase.getInstance().getReference().child("Products")
                .child(prId).child("Ratings").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                pratinngSum=0;
                for (DataSnapshot ds : snapshot.getChildren()) {
                    float prating=Float.parseFloat(""+ds.child("ratings").getValue());
                    pratinngSum=pratinngSum+prating;
                    ModelReview modelReview = ds.getValue(ModelReview.class);
                    previewsList.add(modelReview);

                }

               adapterProdReview.submitList(previewsList);
                long numOfRev=snapshot.getChildrenCount();
                float avgRat=pratinngSum/numOfRev;

                pratingsTv.setText(String.format("%.2f",avgRat)+"["+numOfRev+"]");
                pratingBar2.setRating(avgRat);


            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }
}