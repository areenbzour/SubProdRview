package com.example.groceryapp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.groceryapp.R;
import com.example.groceryapp.models.ModelReview;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class AdapterProdReview extends RecyclerView.Adapter<AdapterProdReview.HolderpReview> {

    private Context context;
    private List<ModelReview> previewArrayList;

    public void submitList(List<ModelReview> list){
        previewArrayList = list;
        notifyDataSetChanged();
    }

    public  AdapterProdReview(Context context, ArrayList<ModelReview> previewArrayList) {
        this.context = context;
        this.previewArrayList = previewArrayList;
    }

    @NonNull
    @Override
    public AdapterProdReview.HolderpReview onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.show_prod_review,parent,false);

        return new AdapterProdReview.HolderpReview(view) ;
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterProdReview.HolderpReview holder, int position) {
        ModelReview modelReview =previewArrayList.get(position);
        String uid=modelReview.getUid();
        String ratings=modelReview.getRatings();
        String timestamp=modelReview.getTimestamp();
        String review=modelReview.getReview();

        loadUserDetails(modelReview,holder);

        DateFormat df = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        if (timestamp != null){
            String formattedDate=df.format( new Date(Long.parseLong(timestamp)));
            holder.pdateTV3.setText(formattedDate);
        }
        holder.pratingBar3.setRating(Float.parseFloat(ratings));
        holder.previewTv3.setText(review);

    }

    private void loadUserDetails(ModelReview modelReview, HolderpReview holder) {
        String uid=modelReview.getUid();
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users");
        ref.child(uid)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        String name=""+snapshot.child("name").getValue();
                        holder.pnameTv3.setText(name);

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }

    @Override
    public int getItemCount() {
        return previewArrayList.size();
    }

    class HolderpReview extends RecyclerView.ViewHolder {
        private ImageView pprofileIv3;
        private TextView pnameTv3,pdateTV3,previewTv3;
        private RatingBar pratingBar3;
        public HolderpReview(View itemView)
        {
            super(itemView);

            pprofileIv3=itemView.findViewById(R.id.pprofileIv3);
            pnameTv3=itemView.findViewById(R.id.pnameTv3);
            pratingBar3=itemView.findViewById(R.id.pratingBar3);
            pdateTV3=itemView.findViewById(R.id.pdateTV3);
            previewTv3=itemView.findViewById(R.id.previewTv3);
        }

    }
}
